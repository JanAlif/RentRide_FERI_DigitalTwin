package GUI

import androidx.compose.ui.graphics.Color

val DeepBlue = Color(0xFF0D47A1)
val LightBlue = Color(0xFF42A5F5)
var DarkerBlue = Color(0xFF3484C4)
val Gray = Color(0xFFB0BEC5)
val LightGray = Color(0xFFECEFF1)
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)